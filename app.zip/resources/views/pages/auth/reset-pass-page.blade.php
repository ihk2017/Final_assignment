@extends('layout.app')
@section('content')
    @include('components.auth.reset-pass-form')
@endsection

