@extends('layout.sidenav-layout')
@section('content')
    @include('components.dashboard.dashboard')
@endsection
