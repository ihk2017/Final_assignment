@extends('layout.app')

@section('content')

<div class="container-fluid">

    <h1 style="font-size:70px;" class="text-center">Welcome to IHK Shopping Paradise</h1>
    <div class="row ">
        <div class="col-4">   </div>
        <div class="col-4  text-center">     
            <a href="{{url("/userLogin")}}" class="btn  bg-gradient-primary ">Start Here</a> 
            <div class="p-5">
                {{-- <ul>
                    <li>Phase 01-------> Start</li>
                    <li>Phase 02</li>
                    <li>Phase 03</li>
                    <li>Phase 04</li>
                    <li>Phase 05</li>
        
                </ul> --}}
                {{-- <button class="btn float-start bg-gradient-primary ">Get started </button> --}}
            </div>
            
            {{-- <a href="{{url("/userLogin")}}" class="btn float-start bg-gradient-primary text-center">Start Here</a> --}}
        </div>
        <div class="col-4">  </div>
    </div>
    
</div>

@endsection
