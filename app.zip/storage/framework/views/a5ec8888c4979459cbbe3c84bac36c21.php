<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <h1 style="font-size:70px;" class="text-center">Welcome to IHK Shopping Paradise</h1>
    <div class="row ">
        <div class="col-4">   </div>
        <div class="col-4  text-center">     
            <a href="<?php echo e(url("/userLogin")); ?>" class="btn  bg-gradient-primary ">Start Here</a> 
            <div class="p-5">
                
                
            </div>
            
            
        </div>
        <div class="col-4">  </div>
    </div>
    
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ostad_materials\ostad_module14_sales_inventory\resources\views/pages/home.blade.php ENDPATH**/ ?>